
from socket import socket, gethostname
from function.member import register
from pickle import dumps, loads
from pickle import UnpicklingError

s = socket()
host = gethostname()
port = 1234

s.connect(
    (host, port)
)

server_data = s.recv(1024)
params = loads(server_data)()
if params:
    s.send(dumps(
        {
            "func": register,
            "params": params
        }
    ))
else:
    print("Login")
    s.send("exit".encode())

while True:
    server_data = s.recv(1024)

    if hasattr(server_data, "decode"):
        try:
            tmp = loads(server_data)
            tmp("Create user complete!!")
            break

        except UnpicklingError as e:
            print("Client Exception")
            if server_data.decode().upper() == ("EXIT"):
                print("Exception Exit")
                s.send('exit'.encode())
                break
            else:
                print("Exception Not Exit")
                print(server_data.decode())

    else:
        print("Else")
        if server_data.decode().upper() == ("EXIT"):
            print("Else if in")
            s.send('exit'.encode())
            break
        else:
            print(server_data.decode())


s.close()
